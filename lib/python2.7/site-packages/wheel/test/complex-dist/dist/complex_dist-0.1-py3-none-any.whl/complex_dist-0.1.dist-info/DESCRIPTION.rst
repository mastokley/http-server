Another testing distribution ☃


